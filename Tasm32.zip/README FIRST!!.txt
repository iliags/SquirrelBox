I have included TASM and Devpac8x and set them up according
to the instuctions in "Learn TI-83 Plus Assembly in 28 Days".
I modifies Asm.bat though so that it automatically changes
to the expected directory, so it can be launched anywhere.
(website: http://nwps.ws/~dragonfire/Asmin28/lesson/toc.html)

Source: Put your assembly source files here (*.z80 and *.asm)
  Exec: Programs compiled using asm.bat will end up in here
  Tasm: Contains Tasm, DevPac8x, asm.bat, and any *.inc files

Run asm.bat to compile your programs. Note that it expects
everything to be in in C:\Asm, so set move everything there
so that you have C:\Asm\Tasm, C:\Asm\Source, and C:\Asm\Exec
(If you want to use a different directory, you will have to
open asm.bat as a text file (use Notepad or something) and
manually configure it to use the directories that you want).

For example, to compile "Hello.z80" from the Source folder,
you would do this from the Windows command prompt:

C:\SomeOtherStaringDirectory\> C:\Asm\Tasm\Asm Hello

...and you would see a bunch of stuff telling you about the
compilation process. Note: put any include files you need
in the Tasm folder (i.e. ti83plus.inc or mirage.inc, which
are both already included by the way).